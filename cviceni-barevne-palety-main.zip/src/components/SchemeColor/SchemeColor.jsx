import './scheme-color.css'

export const SchemeColor = ({ color }) => {
  return (
    <div key={color} className="scheme-color" style={{ backgroundColor: color }}>
      {color}
    </div>
)};

