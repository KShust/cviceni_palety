# Barevné palety

Zadání cvičeného projektu Barevné palety
